<div class="breadcrumb">
    <div class="container d-flex">
        <li>
            <a href="index.html">Home</a>
        </li>
        <i class="fas fa-angle-right"></i>
        <li>
            <a href="#">{{$Page}}</a>
        </li>

    </div>
</div>
